# Disclaimer

## Experimental Project

This is an **experimental personal project** created by Le Manh Thanh.

## No Affiliation

This project is:

- **NOT affiliated** with any organization, company, or institution
- **NOT endorsed** by any government, university, or foundation
- **NOT a commercial product**

## No Warranty

This software is provided "as is", without warranty of any kind.
The author makes no claims about:

- Production readiness
- Security guarantees
- Fitness for any particular purpose
- Market demand or adoption

## Use At Your Own Risk

By using this software, you acknowledge that:

- You are responsible for evaluating its suitability for your use case
- The author is not liable for any damages arising from its use
- This is experimental code that may contain bugs or security issues

## Personal Project

This project represents the personal views and work of the author alone.
It does not represent the views of any employer, organization, or institution.

---

_Le Manh Thanh_
_December 2025_
