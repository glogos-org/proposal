"""
Glogos Attester Tests
"""
